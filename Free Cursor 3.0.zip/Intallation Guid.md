_____________Intallation Guid_________________

========1. Download the latest version of Extension as zip file

========2. Goto download folder and exract the zip file into specific folder e.g: (c/user/user-name/Chrome-extentions

========3. After these steps open the browser 

========4. Type these url(chrome://extensions/, opera://extensions/, firefoxe://extensions/ or  edge://extensions/) in adress bar

========5. Or press on three  🕃 dots right top corner of the browser and goto settings/extensions

========6. In Extention page find the developer toggle button and click on it

========7. When develper options is on select the "load unpacked" option 

========8. Find the extention folder in pc drictory and press enter or click on select 

========9. Exten is loaded and enjoy the new exprience with usefull & heipfull functionality through the Our api